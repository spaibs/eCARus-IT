package com.example.gtflauncher.tower;

import android.util.Log;

public class TowerMessageFactory
{
    public final static String LOG_TAG = "TowerMessageFactory";

    // Pass the complete message to this function
    public static TowerMessage parse(final byte[] messageBuffer)
    {
        TowerMessage parsedMessage = null;

        final int messageId = TowerMessage.parseId(messageBuffer);
        switch(messageId)
        {
            case LightStateMessage.VALID_MESSAGE_ID:
                parsedMessage = new LightStateMessage(messageBuffer);
                break;

            case GestureMessage.VALID_MESSAGE_ID:
                parsedMessage = new GestureMessage(messageBuffer);
                break;

            default:
                Log.w(LOG_TAG, "Unhandled message. Id: " + TowerMessage.parseId(messageBuffer));
                break;
        }

        return parsedMessage;
    }

}
