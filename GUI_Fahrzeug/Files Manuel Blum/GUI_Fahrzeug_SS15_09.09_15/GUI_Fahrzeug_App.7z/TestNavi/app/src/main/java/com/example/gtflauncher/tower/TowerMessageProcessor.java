package com.example.gtflauncher.tower;

import com.example.gtflauncher.tower.TowerMessage;

public interface TowerMessageProcessor
{
    void processTowerMessage(final TowerMessage message);
}
